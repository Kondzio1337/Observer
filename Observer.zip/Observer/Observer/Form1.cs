namespace Observer
{
    public partial class Form1 : Form
    {
        private NBP nbp;
        private Sklep pierwszy;
        private Sklep drugi;
        //private TextBox 

        public void dodajKolumny()
        {
            listView1.Columns.Add("Nazwa", 100);
            listView1.Columns.Add("CenaPLN", 100);
            listView1.Columns.Add("Cena orginalna", 100);
            listView1.Columns.Add("Kraj", 100);

            listView2.Columns.Add("Nazwa", 100);
            listView2.Columns.Add("CenaPLN", 100);
            listView2.Columns.Add("Cena orginalna", 100);
            listView2.Columns.Add("Kraj", 100);
        }
        public Form1()
        {
            InitializeComponent();
            nbp = new NBP();
            pierwszy = new Sklep();
            drugi = new Sklep();
            Produkt monitor = new Produkt(Kraje.Francja, nbp.getKurs(Kraje.Francja), 50.0, "Ksi��ka");
            Produkt monitorLCD = new Produkt(Kraje.Szwecja, nbp.getKurs(Kraje.Szwecja), 5000.0, "P�yta");
            Produkt Myszka = new Produkt(Kraje.Francja, nbp.getKurs(Kraje.Francja), 5.0, "Gra");
            Produkt Klawiatura = new Produkt(Kraje.Szwajcaria, nbp.getKurs(Kraje.Szwajcaria), 13.0, "Plansz�wka");
            Produkt podkladka = new Produkt(Kraje.Bia�oru�, nbp.getKurs(Kraje.Bia�oru�), 1500.0, "Pokrowiec");
            Produkt pad = new Produkt(Kraje.Szwajcaria, nbp.getKurs(Kraje.Szwajcaria), 20.0, "telefon");
            Produkt tablet = new Produkt(Kraje.Szwecja, nbp.getKurs(Kraje.Szwecja), 15000.0, "s�uchawki");
            pierwszy.dodajTowar(monitor);
            drugi.dodajTowar(monitorLCD);
            pierwszy.dodajTowar(Myszka);
            drugi.dodajTowar(Klawiatura);
            drugi.dodajTowar(podkladka);
            pierwszy.dodajTowar(pad);
            drugi.dodajTowar(tablet);

            dodajKolumny();


            Kraje[] wartosciKraje = (Kraje[])Enum.GetValues(typeof(Kraje));
            comboBox1.DataSource = wartosciKraje;

            foreach (var item in pierwszy.getListe())
            {
                nbp.ZarejestrujObserwatora(item.pobierzKraj(), pierwszy);
                ListViewItem nowy = new ListViewItem(item.pobierzNazwe());
                nowy.SubItems.Add(item.pobierzCenaPLN().ToString());
                nowy.SubItems.Add(item.getCenaOrignalna().ToString());
                nowy.SubItems.Add(item.pobierzKraj().ToString());
                listView1.Items.Add(nowy);
            }

            foreach (var item in drugi.getListe())
            {
                nbp.ZarejestrujObserwatora(item.pobierzKraj(), drugi);
                ListViewItem nowy = new ListViewItem(item.pobierzNazwe());
                nowy.SubItems.Add(item.pobierzCenaPLN().ToString());
                nowy.SubItems.Add(item.getCenaOrignalna().ToString());
                nowy.SubItems.Add(item.pobierzKraj().ToString());
                listView2.Items.Add(nowy);
            }



        }
        private void OdswiezListView()
        {
            listView1.Clear();
            listView2.Clear();

            dodajKolumny();

            foreach (var item in pierwszy.getListe())
            {
              //  nbp.ZarejestrujObserwatora(item.getKraj(), pierwszy);
                ListViewItem nowy = new ListViewItem(item.pobierzNazwe());
                nowy.SubItems.Add(item.pobierzCenaPLN().ToString());
                nowy.SubItems.Add(item.getCenaOrignalna().ToString());
                nowy.SubItems.Add(item.pobierzKraj().ToString());
                listView1.Items.Add(nowy);
            }

            foreach (var item in drugi.getListe())
            {
               // nbp.ZarejestrujObserwatora(item.getKraj(), drugi);
                ListViewItem nowy = new ListViewItem(item.pobierzNazwe());
                nowy.SubItems.Add(item.pobierzCenaPLN().ToString());
                nowy.SubItems.Add(item.getCenaOrignalna().ToString());
                nowy.SubItems.Add(item.pobierzKraj().ToString());
                listView2.Items.Add(nowy);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            double wartosc = double.Parse(textBox1.Text);
            if(wartosc>0) {

                if (comboBox1.SelectedItem != null)
                {
                    Kraje wybranyKraj = (Kraje)comboBox1.SelectedItem;
                    nbp.ZmienKurs(wybranyKraj, wartosc);

                    OdswiezListView();
                }

            }
        }
    }
}
