﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Observer
{
    public enum Kraje
    {
        Szwajcaria,
        Francja,
        Szwecja,
        Białoruś  
    }
    public class NBP
    {
         Dictionary<Kraje, double> Kursy = new Dictionary<Kraje, double>();
         Dictionary<Obserwatorzy, List<Kraje>> obserwatorzy = new Dictionary<Obserwatorzy, List<Kraje>>();

        public NBP() {
            Kursy.Add(Kraje.Szwajcaria, 5.0);
            Kursy.Add(Kraje.Francja, 4.0);
            Kursy.Add(Kraje.Szwecja, 0.02);
            Kursy.Add(Kraje.Białoruś, 0.1);
        }
        public double getKurs(Kraje kraj)
        {
            return Kursy[kraj];
        }

        public void ZarejestrujObserwatora(Kraje kraj,Sklep sklep)
        {
            List<Kraje> list;
            if (!obserwatorzy.ContainsKey(sklep))
            {
                list=new List<Kraje>();
                list.Add(kraj);
                obserwatorzy.Add(sklep, list);

            }
            else
            {
                list = obserwatorzy[sklep];
                if (!list.Contains(kraj))
                {
                    list.Add(kraj);
                }
                obserwatorzy[sklep] = list;
            }
            

        }
        public void ZmienKurs(Kraje kraj,double nowyKurs)
        {
            Kursy[kraj] = nowyKurs;
            foreach(var k in obserwatorzy)
            {
                Obserwatorzy sklep = k.Key;
                List<Kraje> list = k.Value;

                foreach(var kraje in list)
                {
                    if(kraje == kraj)
                    {
                        sklep.aktualizujCene(kraj, nowyKurs);
                    }
                }
            }
        }
    }

}
