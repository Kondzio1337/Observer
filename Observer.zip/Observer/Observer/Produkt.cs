﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Observer
{

    public class Produkt
    {
        private Kraje krajPochodzenia;
        private double cenaPLN;
        private double cenaOrginalna;
        private string nazwa;

        public Kraje pobierzKraj()
        {
            return krajPochodzenia;
        }
        public double getCenaOrignalna()
        {
            return cenaOrginalna;
        }
        public string pobierzNazwe() { return  nazwa; }
        public double pobierzCenaPLN() { return cenaPLN; }
        public void ustawCenaPLN(double kurs) { cenaPLN = kurs*cenaOrginalna; } 
        public Produkt(Kraje kraj, double kurs, double cenaOrginalna,string nazwa)
        {

            this.cenaPLN = kurs*cenaOrginalna;
            this.krajPochodzenia = kraj;
            this.cenaOrginalna = cenaOrginalna;
            this.nazwa = nazwa;
        }
    }
}
