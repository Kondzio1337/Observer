﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Observer
{
    public interface Obserwatorzy
    {
        public void aktualizujCene(Kraje kraj, double kurs);
    }
    public class Sklep:Obserwatorzy
    {
        public List<Produkt> listaTowarow = new List<Produkt>();
        public void dodajTowar(Produkt towar)
        {
            listaTowarow.Add(towar);
        }
        public List<Produkt> getListe()
        {
            return listaTowarow;
        }

        public void aktualizujCene(Kraje kraj,double kurs)
        {
            foreach(var item in listaTowarow)
            {
                if (item.pobierzKraj() == kraj)
                {
                    item.ustawCenaPLN(kurs);
                }
            }
        }
    }
}
